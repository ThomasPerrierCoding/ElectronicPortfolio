function init() {
      alert("hello javascript");
    };

window.addEventListener("load",init,false);

$ = function (id){
  return document.getElementById(id);
}
window.onload = function(){
  var listNode = $("image_list");
  var captionNode = $("caption");
  var imageNode = $("image");

  var imageLinks = listNode.getElementsByTagName("a");

  var i, linkNode, image;
  for (i = 0; i < imageLinks.length; i++) {
    linkNode = imageLinks[i];

    linkNode.onhover = function(evt){
      var link = this;
      imageNode.src = link.getAttribute("href");
      captionNode.firstChild.nodeValue = link.getAttribute("title");

      if (!evt) evt = winow.event;
      if (evt.preventDefault){
        evt.preventDefault();
      }
        else {
          evt.returnValue = false;
        }
      }

      image = new Image();
      image.src = linkNode.getAttribute("href");

  }
  $("first_link").focus();
}
